<?php
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $dbname = "login_register";

    $conn = mysqli_connect($hostname,$user,$password,$dbname);
    if(!$conn){
        die("Something went wrong.");
    }
?>